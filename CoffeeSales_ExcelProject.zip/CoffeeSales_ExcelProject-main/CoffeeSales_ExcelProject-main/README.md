### ExcelProject

#### This project highlights my understanding of utilizing Excel to extract, clean and visualize data to solve problems. By utilizing important Excel functions like XLOOKUP() and creating a viewer experience with data for easy interpetation. 

This data contains information about people around the US who drink select coffee, their personal information, customer IDs and whether they have an ID loyalty card with the company. 

This data was taken from Kaggle.

#### Performance Analysis:
 How effective is the loyalty card program in retaining customers and increasing sales?
 
###### Answer using Dashboard: 
 
#### Data-Drive Decision Making:
 Should there be adjustments in pricing or promotions for select coffee products based on customer demographics or buying behavior?

###### Answer using Dashboard: 
 
#### Predictive Analysis. 
 What factors contribute most to customer retention and loyalty?

###### Answer using Dashboard: 
